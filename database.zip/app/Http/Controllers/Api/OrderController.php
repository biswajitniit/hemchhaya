<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Order_payment_method;
use App\Models\Order_product;
use App\Models\Order_product_tracking;
use App\Models\Order_product_variation;
use App\Models\Order_total;
use App\Models\Order_tracking_shiprocket;
use App\Models\Product;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Nette\Utils\Random;

class OrderController extends Controller
{
    public function my_orders_history(Request $request)
    {

        $data["orderdetails"] = DB::table('orders')->select('orders.id','orders.order_id','orders.user_phone','orders.purchased_date', 'orders.edd', 'order_totals.value')
                                ->join('order_totals','order_totals.order_id','=','orders.order_id')
                                ->where('order_totals.title','Total')
                                ->where('orders.user_id',$request->user()->id)
                                ->where('orders.order_status','!=','1')
                                ->get();
                                return response()->json($data,200);

    }
    public function view_order_details(Request $request, $orderid)
     {
         try{
            $data["orderdetails"] = DB::table('orders')->select('orders.id', 'orders.user_addresses_title', 'orders.user_full_shipping_and_billing_details_info', 'orders.order_id','orders.user_phone', 'orders.edd','orders.purchased_date','orders.order_status','order_totals.value')
                                 ->join('order_totals','order_totals.order_id','=','orders.order_id')
                                 ->where('order_totals.title','Total')
                                 ->where('orders.order_id',$orderid)
                                 ->get()[0];

        $data["orderproducts"]       = Order_product::where('order_id',$orderid)->get();
        $data["orderpaymentmethod"]  = Order_payment_method::where('order_id',$orderid)->first();

        $data["ordersubtotals"]      = Order_total::where('order_id',$orderid)->where('title','Sub Total')->get()[0]->value;
        $data["orderdcost"]          = Order_total::where('order_id',$orderid)->where('title','Delivery Charges')->get()[0]->value;
        $data["ordertotals"]         = Order_total::where('order_id',$orderid)->where('title','Total')->get()[0]->value;

        return response()->json($data,200);
         }
         catch(Exception $e){
            return response()->json($e->getMessage(),500);
         }

     }
    public function create_single_order(Request $request){
        $validator = Validator::make($request->all(), [
            'product_id' => 'required',
            'qty' => 'required',
            'user_full_shipping_and_billing_details_info'=> 'required|string',
            'transaction_id'=> 'required',
            'product_shipping_charge'=>'required',
            'product_variation_id'=>'required',
            'product_variation_item_id'=>'required',
            'courier_company'=>'required',
            'tracking_no'=>'required',
            'delivery_charges'=>'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        try{
            $product = Product::where('id',$request->product_id)->first();
            $order = new Order();
            $order->order_id = 'OD'.strval(rand(100000,999999)).strval(date('His'));
            $order->user_id = $request->user()->id;
            $order->user_phone = $request->user()->phone;
            $order->user_full_shipping_and_billing_details_info = $request->useruser_full_shipping_and_billing_details_info;
            $order->purchase_date = date("Y/m/d");
            $order->transaction_id = $request->transaction_id;
            $order->save();
            $order->refresh();

            $orderProduct = new Order_product();
            $orderProduct->order_id = $order->id;
            $orderProduct->vendor_id = $product->vendor_id;
            $orderProduct->product_id = $product->id;
            $orderProduct->product_price = $product->price;
            $orderProduct->product_shipping_charge = $request->product_shipping_charge;
            $orderProduct->product_final_price = $product->price;
            $orderProduct->product_quantity = $request->qty;
            $orderProduct->order_date = date("Y/m/d");
            $orderProduct->order_status = 1;
            $orderProduct->transaction_id = $request->transaction_id;
            $orderProduct->save();
            $orderProduct->refresh();

            $orderPaymentMethod = new Order_payment_method();
            $orderPaymentMethod->order_id = $order->id;
            $orderPaymentMethod->payment_method	= 'razorpayrazorpay';
            $orderPaymentMethod->transaction_id	= $request->transaction_id;
            $orderPaymentMethod->transaction_capture_history	= $request->transaction_capture_history;
            $orderPaymentMethod->save();

            $orderProductVariations = new Order_product_variation();
            $orderProductVariations->order_id =  $order->id;
            $orderProductVariations->product_id = $product->id;
            $orderProductVariations->product_variation_item_id = $request->product_variation_item_id;
            $orderProductVariations->save();

            $orderProductTracking = new Order_product_tracking();
            $orderProductTracking->order_id = $order->id;
            $orderProductTracking->product_id = $product->id;
            $orderProductTracking->courier_company = $request->courier_company;
            $orderProductTracking->tracking_no = $request->tracking_no;
            $orderProductTracking->save();

            $ordersubtotal = new Order_total();
            $ordersubtotal->order_id   = $order->id;
            $ordersubtotal->title      = 'Sub Total';
            $ordersubtotal->text       = 'Sub Total';
            $ordersubtotal->value      = str_replace(',', '', $product->price * $request->qty);
            $ordersubtotal->save();

            $orderdeliverycost = new Order_total();
            $orderdeliverycost->order_id   = $order->id;
            $orderdeliverycost->title      = 'Delivery Charges';
            $orderdeliverycost->text       = 'Delivery Charges';
            $orderdeliverycost->value      = $request->delivery_charges;
            $orderdeliverycost->save();

            $ordertotal = new Order_total();
            $ordertotal->order_id   = $order->id;
            $ordertotal->title      = 'Total';
            $ordertotal->text       = 'Total';
            $ordertotal->value      = str_replace(',', '', number_format($product->price * $request->qty + $request->delivery_charges,2));
            $ordertotal->save();


            return response()->json(["message"=>'Order saved successfully'],200);
            
        } catch(Exception $e){
            return response()->json(["error"=>$e->getMessage()],500);
        }
    }

    function cart_order(Request $request){
            //1st Save data in order table
            $orderid= "OD".date('Ymd').rand();
            $userid = $request->user()->id;
            $order = new Order();
                $order->order_id                                      = $orderid;
                $order->user_id                                       = $userid;
                $order->user_phone                                    = $request->user()->phone;
                $order->user_full_shipping_and_billing_details_info   = 'Test';
                $order->purchased_date                                = date('Y-m-d H:i:s');
            $order->save();
            //$orderid= $order->id;

            //2nd Save data in order_products
            $total = 0;
            $subtotal = 0;
            $weight = 0;
            $length = 0;
            $breadth = 0;
            $height = 0;
            //$order_items = array();

            $cart = Cart::where('user_id',$request->user()->id)->get();
            foreach($cart as $row){
                $subtotal = $subtotal + ($row->price * $row->qty);
                $productinfo = json_decode($row->attributes);

                $weight      = $weight + ($productinfo->weight * $row->qty);
                $length      = $length + $productinfo->length;
                $breadth     = $breadth + $productinfo->breadth;
                $height      = $height + $productinfo->height;

                $orderproduct = new Order_product();
                    $orderproduct->order_id                    = $orderid;
                    $orderproduct->vendor_id                   = $productinfo->vendor_id;
                    $orderproduct->product_id                  = $row->product_id;
                    $orderproduct->product_price               = $row->price;
                    $orderproduct->product_tax_price           = '0.00';
                    $orderproduct->product_shipping_charge     = '0.00';
                    $orderproduct->product_final_price         = $row->price;
                    $orderproduct->product_quantity            = $row->qty;
                    $orderproduct->order_date                  = date('Y-m-d H:i:s');
                    $orderproduct->order_status                = '2'; // Order status is received
                $orderproduct->save();

                $order_items[] = array('name'=>$row->name,'sku'=>$productinfo->sku,'units'=>$row->qty,'selling_price'=>$row->price,'discount'=>'','tax'=>'','hsn'=>'');

            }

            //3rd Save data in order_totals
            $ordersubtotal = new Order_total();
                $ordersubtotal->order_id   = $orderid;
                $ordersubtotal->title      = 'Sub Total';
                $ordersubtotal->text       = 'Sub Total';
                $ordersubtotal->value      = str_replace(',', '', $subtotal);
            $ordersubtotal->save();

            $orderdeliverycost = new Order_total();
                $orderdeliverycost->order_id   = $orderid;
                $orderdeliverycost->title      = 'Delivery Charges';
                $orderdeliverycost->text       = 'Delivery Charges';
                $orderdeliverycost->value      = $request->delivery_charges;
            $orderdeliverycost->save();

            $ordertotal = new Order_total();
                $ordertotal->order_id   = $orderid;
                $ordertotal->title      = 'Total';
                $ordertotal->text       = 'Total';
                $ordertotal->value      = str_replace(',', '', number_format($subtotal + $request->delivery_charges,2));
            $ordertotal->save();


            //4th Save data in order payment capture history
            $orderpaymenthistory = new Order_payment_method();
                $orderpaymenthistory->order_id                         = $orderid;
                $orderpaymenthistory->payment_method                   = "razorpayrazorpay";
                $orderpaymenthistory->transaction_id                   = '';
                $orderpaymenthistory->transaction_capture_history      = '';
            $orderpaymenthistory->save();


            $ordertrackingshiprocket = new Order_tracking_shiprocket();
                $ordertrackingshiprocket->order_id                   = $orderid;
                $ordertrackingshiprocket->shiprocket_order_id        = $request->shiprocket_order_id;
                $ordertrackingshiprocket->shipment_id                = $request->shipment_id;
                $ordertrackingshiprocket->status                     = $request->status;
                $ordertrackingshiprocket->status_code                = $request->status_code;
                $ordertrackingshiprocket->onboarding_completed_now   = $request->onboarding_completed_now;
                $ordertrackingshiprocket->awb_code                   = $request->awb_code;
                $ordertrackingshiprocket->courier_company_id         = $request->courier_company_id;
                $ordertrackingshiprocket->courier_name               = $request->courier_name;
            $ordertrackingshiprocket->save();


            $toemail = $request->user()->email;
            return response()->json(["message"=>'Order saved successfully'],200);


            Mail::send('email.order_success_template', ["id"=>$orderid,"order_id"=>$orderid,"payment_method"=>"Prepaid","user_full_shipping_details_info"=>"Test","user_phone"=>"8768624650"], function($message) use ($toemail){
                $message->to($toemail);
                //$message->bcc('test@salesanta.com');
                $message->subject('Your Order Received Successfully');
            });


            return response()->json(["message"=>'Order saved successfully'],200);
      
    }
}
