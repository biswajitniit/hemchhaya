<?php
return [
    'Shiprocket' => [
        'email' => 'biswajitmaityniit@gmail.com',
        'password' => 'Bisu#123'
    ]
];
